//
//  SMFViewMenuController.h
//  SMFramework
//
//  Created by Thomas Cool on 1/6/11.
//  Copyright 2011 tomcool.org. All rights reserved.
//

#import <Backrow/Backrow.h>

/*
 *  DO NOT USE YET
 */
@interface SMFViewMenuController : BRViewController {

}
+(SMFViewMenuController *)menuViewController;
@end
