//
//  SMFCenteredMediaMenuController.h
//  SoftwareMenuFramework
//
//  Created by Thomas Cool on 2/25/10.
//  Copyright 2010 Thomas Cool. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Backrow/Backrow.h>
#import "SMFMediaMenuController.h"
#import "SMFMenuController.h"
#import "SMFDefines.h"
@class SMFMenuController;
@interface SMFCenteredMenuController : SMFMenuController {

}

@end
