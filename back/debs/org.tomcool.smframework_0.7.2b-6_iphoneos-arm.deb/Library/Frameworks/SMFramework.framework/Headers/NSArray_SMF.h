//
//  NSArray_SMF.h
//  SMFramework
//
//  Created by Thomas Cool on 12/27/10.
//  Copyright 2010 tomcool.org. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSArray (SMFramework)
-(NSArray *)SMFShuffled;
@end
