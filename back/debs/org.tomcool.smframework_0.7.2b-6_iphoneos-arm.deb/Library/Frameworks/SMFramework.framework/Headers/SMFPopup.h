//
//  SMFPopup.h
//  SMFramework
//
//  Created by Thomas Cool on 11/20/10.
//  Copyright 2010 tomcool.org. All rights reserved.
//

#import <Backrow/Backrow.h>

@interface SMFPopupInfo : BRTrackInfoControl


@end
