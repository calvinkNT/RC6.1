#!/bin/bash
export PATH=/usr/bin:/bin:/sbin:/usr/sbin
reboot